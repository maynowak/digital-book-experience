import { chromium, type Page } from 'playwright'
import { createServer, type ViteDevServer } from 'vite'
import { resolve } from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')

type ElementReport = Record<string, string>

type LayerReport = {
  posterContainer: ElementReport | null
  posterImage: ElementReport | null
  video: ElementReport | null
  hints: string[]
}

const LAYOUT_PROPS = [
  'offsetWidth', 'offsetHeight', 'clientWidth', 'clientHeight',
]

const COMPUTED_PROPS = [
  'opacity', 'transform', 'willChange', 'isolation', 'zIndex',
  'mixBlendMode', 'contain', 'backfaceVisibility', 'perspective',
  'translate', 'scale', 'rotate', 'position', 'pointerEvents',
  'overflow', 'transition', 'animation', 'display',
]

async function startVite(): Promise<ViteDevServer> {
  const server = await createServer({
    root: PROJECT_ROOT,
    server: { port: 5173, strictPort: true },
  })
  await server.listen()
  return server
}

function getStyles(el: HTMLElement): Record<string, string> {
  const cs = getComputedStyle(el)
  const info: Record<string, string> = {}
  for (const prop of COMPUTED_PROPS) {
    info[prop] = cs.getPropertyValue(prop)
  }
  for (const prop of LAYOUT_PROPS) {
    info[prop] = String((el as any)[prop])
  }
  info['tagName'] = el.tagName
  info['className'] = el.className
  return info
}

async function collectLayerData(page: Page): Promise<LayerReport> {
  return page.evaluate(() => {
    const container = document.querySelector<HTMLElement>('[class*="posterContainer"]')
    const image = document.querySelector<HTMLImageElement>('[class*="posterImage"]')
    const video = document.querySelector<HTMLVideoElement>('video')

    const report: LayerReport = {
      posterContainer: container ? getStyles(container) : null,
      posterImage: null,
      video: null,
      hints: [],
    }

    if (image) {
      const info = getStyles(image)
      info['naturalWidth'] = String(image.naturalWidth)
      info['naturalHeight'] = String(image.naturalHeight)
      info['complete'] = String(image.complete)
      info['currentSrc'] = image.currentSrc
      report.posterImage = info
    }

    if (video) {
      const info = getStyles(video)
      info['videoWidth'] = String(video.videoWidth)
      info['videoHeight'] = String(video.videoHeight)
      info['paused'] = String(video.paused)
      info['currentSrc'] = video.currentSrc
      report.video = info
    }

    // Heuristics
    if (image && image.complete && image.naturalWidth > 0) {
      const rect = image.getBoundingClientRect()
      const vw = window.innerWidth
      const vh = window.innerHeight
      if (rect.right < 0 || rect.left > vw || rect.bottom < 0 || rect.top > vh) {
        report.hints.push(`image is outside viewport (rect: ${JSON.stringify({top: rect.top, right: rect.right, bottom: rect.bottom, left: rect.left, width: rect.width, height: rect.height})})`)
      }
      if (rect.width === 0 || rect.height === 0) {
        report.hints.push('image has zero bounding rect')
      }
    }

    for (const [label, el] of Object.entries({ container, image, video })) {
      if (!el) continue
      const cs = getComputedStyle(el)
      const wc = cs.getPropertyValue('willChange')
      if (wc && wc !== 'auto') report.hints.push(`${label}: willChange:${wc} → compositor layer`)
      if (cs.getPropertyValue('transform') !== 'none') report.hints.push(`${label}: has transform → compositor layer`)
      if (cs.getPropertyValue('isolation') === 'isolate') report.hints.push(`${label}: isolation:isolate → stacking context`)
      if (cs.getPropertyValue('contain')) {
        const c = cs.getPropertyValue('contain')
        if (['paint', 'layout', 'strict', 'content'].includes(c)) report.hints.push(`${label}: contain:${c} → stacking context`)
      }
    }

    if (container && image) {
      const co = getComputedStyle(container).opacity
      const io = getComputedStyle(image).opacity
      const ct = getComputedStyle(container).getPropertyValue('transition')
      const it = getComputedStyle(image).getPropertyValue('transition')
      report.hints.push(`container opacity=${co} transition=${ct}`)
      report.hints.push(`image opacity=${io} transition=${it}`)
    }

    if (container && video) {
      const rectC = container.getBoundingClientRect()
      const rectV = video.getBoundingClientRect()
      report.hints.push(`container rect: ${JSON.stringify(rectC)}`)
      report.hints.push(`video rect: ${JSON.stringify(rectV)}`)
    }

    if (container) {
      const parent = container.parentElement
      if (parent) {
        const ps = getComputedStyle(parent)
        report.hints.push(`parent (${parent.className}): display=${ps.display} isolation=${ps.isolation} position=${ps.position}`)
      }
    }

    return report
  })
}

async function dumpCompositingLayers(page: Page) {
  try {
    const cdp = await page.context().newCDPSession(page)
    await cdp.send('LayerTree.enable')
    const { layers } = await cdp.send('LayerTree.compositingReasons' as any)
    console.log('  CDP compositing reasons:', JSON.stringify(layers, null, 2))
  } catch (e) {
    console.log('  CDP layer info skipped:', (e as Error).message)
  }
}

async function main() {
  console.log('Starting Vite dev server...')
  const server = await startVite()
  const url = 'http://localhost:5173'

  console.log(`Opening ${url} ...`)
  const browser = await chromium.launch({ headless: true })
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } })
  const page = await context.newPage()

  page.on('console', (msg) => {
    if (msg.type() === 'error') console.error('  browser error:', msg.text())
  })

  await page.goto(url, { waitUntil: 'networkidle' })
  await page.waitForTimeout(2000)
  await page.waitForSelector('[class*="posterContainer"]', { timeout: 5000 })
  console.log('Reels section found\n')

  console.log('=== Layer Report ===')
  const report = await collectLayerData(page)
  for (const [key, val] of Object.entries(report)) {
    if (key === 'hints') continue
    console.log(`\n--- ${key} ---`)
    if (val) {
      for (const [k, v] of Object.entries(val)) {
        console.log(`  ${k}: ${v}`)
      }
    } else {
      console.log('  (not found)')
    }
  }

  if (report.hints.length) {
    console.log('\n--- Hints ---')
    for (const h of report.hints) console.log(`  • ${h}`)
  }

  await dumpCompositingLayers(page)

  await browser.close()
  await server.close()
  console.log('\nDone.')
}

main().catch((err) => {
  console.error('Fatal:', err)
  process.exit(1)
})
